IV1M1 — Subsequential infinite-volume limits for lattice gauge fields

Canonical LaTeX source for the revised 20-page manuscript.
Build in this directory with a current TeX distribution:

    pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
    biber main
    pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
    pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex

main.tex is the entry point. All included source files, the style package,
and the bibliography are supplied. No shell escape is needed.
